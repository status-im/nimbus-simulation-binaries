# Windows-specific requirements

Run the wrapper scripts from a [Git for Windows](https://gitforwindows.org/)
Bash shell or an MSYS2 terminal emulator.

If you run the Nimbus binary directly, prefix it with "winpty -- ". It
will increase the chance of Ctrl+C working inside that "mintty" terminal emulator.

